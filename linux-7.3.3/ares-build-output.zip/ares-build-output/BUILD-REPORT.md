# ares 自动构建报告

- 生成时间: 2026-11-14 14:39:50 +0800
- 内核树  : /workspace/linux-7.3.3
- 内核版本: 7.3.3
- 工具链  : Ubuntu clang version 18.1.3 (1ubuntu1) / Ubuntu LLD 18.1.3 (compatible with GNU linkers)
- 并行度  : -j32
- 构建形态: 模块版（默认）—— 9 个 B 类驱动 =m，另产出 .ko
- 产物目录: /workspace/linux-7.3.3/ares-build-output

## 阶段结果

| 阶段 | 结果 | 耗时 | 日志 |
|---|---|---|---|
| install | ✅ 通过 | 1s | logs/install.log |
| force-config | ✅ 通过 | 0s | logs/force-config.log |
| defconfig | ✅ 通过 | 6s | logs/defconfig.log |
| collect | ✅ 通过 | 0s | logs/collect.log |
| report | ✅ 通过 | 0s | logs/report.log |
| package | ✅ 通过 | — | logs/package.log |

> 注：`report` / `package` 在报告生成后执行，完整结果以控制台汇总为准。

## 强制写入 defconfig 的配置项

共 88 项，已在 defconfig 中做到
「每个符号恰好出现一次、值唯一」；额外包含 `CONFIG_VIRTUALIZATION=y`、
`CONFIG_KVM=y`、`CONFIG_NTSYNC=y`。

### .config 实际生效值（节选）

```
CONFIG_VIRTUALIZATION=y
CONFIG_KVM=y
CONFIG_REGMAP_I2C=y
CONFIG_NTSYNC=y
CONFIG_REGULATOR_WL2866D=m
CONFIG_HAPTIC_AW8697=m
CONFIG_TOUCHSCREEN_GT9886=m
```

- 与期望值不一致（被 Kconfig 依赖调整 / 父级未启用）的项: **2**

```
  CONFIG_SND_SOC_CS35L41: 期望 y, 实际 MISSING
  CONFIG_SND_SOC_CS35L41_I2C: 期望 m, 实际 MISSING
```

> 属 Kconfig 依赖约束，**不是写入失败**。常见原因：干净 arm64 defconfig
> 未开 `CONFIG_SOUND`，ASoC 子项 `SND_SOC_CS35L41*` 被整体裁掉而显示
> `MISSING`；`--builtin` 形态显式提升 `SOUND/SND/SND_SOC=y` 则无此现象。
> 与本包 9 个移植驱动、dtb 及 initramfs 无关。

## 产物

```
  ./.config 301690 bytes
  ./config-verify.txt 2217 bytes
  ./defconfig.forced 50182 bytes
  ./Image 42785280 bytes
  ./logs/collect.log 489 bytes
  ./logs/defconfig.log 708 bytes
  ./logs/force-config.log 949 bytes
  ./logs/install.log 2738 bytes
  ./logs/port-build.log 1641 bytes
  ./logs/report.log 0 bytes
  ./modules/et7480-audioswitch.ko 325520 bytes
  ./modules/gf3658-spi.ko 378048 bytes
  ./modules/haptic-aw8697.ko 354704 bytes
  ./modules/input-gamekey.ko 271520 bytes
  ./modules/leds-aw2028.ko 334984 bytes
  ./modules/regulator-wl2866d.ko 350536 bytes
  ./modules/st21nfc.ko 343144 bytes
  ./modules/touchscreen-gt9886.ko 367776 bytes
  ./modules/xmusb350-charger.ko 348800 bytes
  ./mt6893-xiaomi-ares-official.dtb 222232 bytes
  ./System.map 9374453 bytes
```

## 失败项说明与建议

全部阶段通过。
